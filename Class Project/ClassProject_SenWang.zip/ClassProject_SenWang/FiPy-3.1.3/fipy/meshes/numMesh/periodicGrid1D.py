
from fipy.meshes.numMesh.deprecatedWarning import numMeshDeprecated
from fipy.meshes.periodicGrid1D import *

numMeshDeprecated()


