
from fipy.meshes.numMesh.deprecatedWarning import numMeshDeprecated
from fipy.meshes.cylindricalGrid1D import *

numMeshDeprecated()


