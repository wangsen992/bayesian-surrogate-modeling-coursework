
from fipy.meshes.numMesh.deprecatedWarning import numMeshDeprecated
from fipy.meshes.uniformGrid3D import *

numMeshDeprecated()


