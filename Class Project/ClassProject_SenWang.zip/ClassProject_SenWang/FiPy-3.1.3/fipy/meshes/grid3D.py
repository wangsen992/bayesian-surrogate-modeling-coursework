from fipy.meshes.nonUniformGrid3D import NonUniformGrid3D as Grid3D
import warnings
warnings.warn("Grid3D has been deprecated use NonUniformGrid3D instead.", stacklevel=3)
