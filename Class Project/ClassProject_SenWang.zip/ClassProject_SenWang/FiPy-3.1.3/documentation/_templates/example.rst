{{ fullname }}
{{ underline }}

.. automodule:: {{ module }}.{{ objname }}
