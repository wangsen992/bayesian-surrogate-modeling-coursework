package package
===============

Subpackages
-----------

.. toctree::

    package.subpackage

Module contents
---------------

.. automodule:: package
    :members:
    :undoc-members:
    :show-inheritance:
