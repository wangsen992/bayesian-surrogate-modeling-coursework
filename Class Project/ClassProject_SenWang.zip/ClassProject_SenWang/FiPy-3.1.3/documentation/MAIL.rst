------------
Mailing List
------------

In order to discuss :term:`FiPy` with other users and with the developers, 
we encourage you to sign up for the mailing list by sending a
`subscription email <mailto:fipy-request@nist.gov?&body=subscribe>`__:

    To:
	``fipy-request@nist.gov``

    Subject:
	*(optional)*

    Body:
	``subscribe``

Once you are subscribed, you can post messages to the list simply by
addressing email to mailto:fipy@nist.gov. If you are new to mailing
lists, you may want to read the following resource about asking
effective questions:  http://www.catb.org/~esr/faqs/smart-questions.html

To get off the list follow the instructions above, but place
``unsubscribe`` in the text body.

Send ``help`` in the text body to learn other mailing list configurations 
you can change.

List Archive
------------

https://www.mail-archive.com/fipy@nist.gov/

Copies of messages sent to fipy@nist.gov are stored at `The Mail Archive`_.

(note: we have also historically sent copies to
http://dir.gmane.org/gmane.comp.python.fipy, but the GMANE_ site now
appears to be defunct_.)


.. _The Mail Archive:   https://www.mail-archive.com

.. _GMANE:    http://gmane.org/

.. _defunct: https://lars.ingebrigtsen.no/2016/07/28/the-end-of-gmane/


