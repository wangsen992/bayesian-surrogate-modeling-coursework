from fipy.meshes.cylindricalNonUniformGrid2D import cylindricalNonUniformGrid2D
import warnings
warnings.warn("CylindricalGrid2D has been deprecated use CylindricalNonUniformGrid2D instead.", stacklevel=3)
