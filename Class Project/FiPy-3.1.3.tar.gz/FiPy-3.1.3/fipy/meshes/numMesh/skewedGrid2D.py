
from fipy.meshes.numMesh.deprecatedWarning import numMeshDeprecated
from fipy.meshes.skewedGrid2D import *

numMeshDeprecated()


