
from fipy.meshes.numMesh.deprecatedWarning import numMeshDeprecated
from fipy.meshes.tri2D import *

numMeshDeprecated()


