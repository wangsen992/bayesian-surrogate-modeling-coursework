
from fipy.meshes.numMesh.deprecatedWarning import numMeshDeprecated
from fipy.meshes.grid3D import *

numMeshDeprecated()


