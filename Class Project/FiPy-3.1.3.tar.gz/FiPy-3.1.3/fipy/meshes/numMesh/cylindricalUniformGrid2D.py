
from fipy.meshes.numMesh.deprecatedWarning import numMeshDeprecated
from fipy.meshes.cylindricalUniformGrid2D import *

numMeshDeprecated()


