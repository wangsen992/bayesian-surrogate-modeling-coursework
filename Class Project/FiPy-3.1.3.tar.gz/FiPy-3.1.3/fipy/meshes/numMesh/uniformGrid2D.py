
from fipy.meshes.numMesh.deprecatedWarning import numMeshDeprecated
from fipy.meshes.uniformGrid2D import *

numMeshDeprecated()


