from fipy.meshes.cylindricalNonUniformGrid1D import cylindricalNonUniformGrid1D
import warnings
warnings.warn("CylindricalGrid1D has been deprecated use CylindricalNonUniformGrid1D instead.", stacklevel=3)
