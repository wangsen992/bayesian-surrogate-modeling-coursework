from fipy.meshes.nonUniformGrid1D import NonUniformGrid1D as Grid1D
import warnings
warnings.warn("Grid1D has been deprecated use NonUniformGrid1D instead.", stacklevel=3)
