.. FiPy documentation master file, created by
   sphinx-quickstart on Sat Aug 29 21:50:21 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

FiPy Contents
=============

.. toctree::

   introduction
   ../examples/README
   ../LICENSE
   ADMINISTRATA
   CREDITS
   EFFICIENCY
   PUBLICATIONS
   VKML
   ../DISCLAIMER
   manual
   references

.. toctree::
   :hidden:

   CODESPEED
   BUILDBOT
   GUIDELINES
   GIT

