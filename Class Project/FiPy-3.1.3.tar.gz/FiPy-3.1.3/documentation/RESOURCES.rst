Computational Resources
-----------------------

- ACCESS: German phase field code, <http://www.micress.de/>
- Dolfyin + Fenics PDE solvers OO, <http://www.fenics.org/>
- <http://www.femcenter.org/>
- Dolfyn, open source CFD, <http://www.dolfyn.net/>
- Openflower
- Trilinos, solvers of all types <http://software.sandia.gov/trilinos>
- Pyrex
- Petc
- matpy
- Ryo's code
- Femlego
- Spectral MATLAB CH
- Femlab
- Diffpack
- Information for validation and verification of numerical codes <http://www.grc.nasa.gov/WWW/wind/valid/tutorial/tutorial.html>
- BLENDER3D: meshing software
- POVRAY: meshing software
