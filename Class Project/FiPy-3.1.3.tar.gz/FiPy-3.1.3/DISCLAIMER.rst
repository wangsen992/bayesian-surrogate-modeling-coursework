----------
Disclaimer
----------

Certain commercial firms and trade names are identified in this document in
order to specify the installation and usage procedures adequately.  Such
identification is not intended to imply recommendation or endorsement by
the `National Institute of Standards and Technology`_, nor is it intended
to imply that related products are necessarily the best available for the
purpose.

.. _National Institute of Standards and Technology: http://www.nist.gov/
