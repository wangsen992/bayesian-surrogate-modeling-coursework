# Instruction

The scripts are contained in the folder *problem3b* and *problem4* respectively. 

* For problem3b, run *naive_bayes.m* within MATLAB. The data filename can be changed in the second line of the script. 
* For problem4, run *empirical_bayes.m* within MATLAB. 

