HW3.pdf: PDF export from the Jupyter Notebook including all required derivations and discussion. 

HW3.html: Same content as HW3.pdf, but with prettier formatting. 

HW3.ipynb: Executable ipython notebook for the solutions of HW3. 

HW3_data: data used in the ipython notebook

