Xtrain (training input), ytrain (traing output).

For ploting decision boundary, form a grid of your choice within the window(X)