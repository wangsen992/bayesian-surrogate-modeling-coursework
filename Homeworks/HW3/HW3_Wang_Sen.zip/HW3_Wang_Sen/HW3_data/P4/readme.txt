The size of the provide data set is 120x3. Out of the 3 columns, the first
two are inputs while the third is the label.

For ploting the decision boundary use,

x = -10:0.1:12;
y = -10:0.1:12;
[X Y] = meshgrid(x,y);